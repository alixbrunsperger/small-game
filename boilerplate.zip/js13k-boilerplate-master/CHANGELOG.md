# 1.1.0 (unpublished)

- Added npm scripts
- Added `serve` task
- Changed `default` to build the project
- Added sample code

# 1.0.0

- Updated dependencies
- Added [`bundle-collapser`](https://github.com/substack/bundle-collapser) to better compress `browserify`-d JavaScript
- Added `CHANGELOG.md`
- Fix watching on LESS files

# 0.1.0

- First release
